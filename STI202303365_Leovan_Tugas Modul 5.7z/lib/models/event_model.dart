class EventModel {
  final String title;
  final String description;
  final double latitude;
  final double longitude;
  final DateTime date;
  final String venue;
  final String category;
  double? distance;

  EventModel({
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.date,
    required this.venue,
    required this.category,
    this.distance,
  });

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'latitude': latitude,
      'longitude': longitude,
      'date': date.toIso8601String(),
      'venue': venue,
      'category': category,
      'distance': distance,
    };
  }

  factory EventModel.fromJson(Map<String, dynamic> json) {
    return EventModel(
      title: json['title'],
      description: json['description'],
      latitude: json['latitude'],
      longitude: json['longitude'],
      date: DateTime.parse(json['date']),
      venue: json['venue'],
      category: json['category'],
      distance: json['distance'],
    );
  }
}
