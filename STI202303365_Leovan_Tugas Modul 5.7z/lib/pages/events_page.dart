import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/event_model.dart';

class EventsPage extends StatefulWidget {
  final Position userPosition;

  const EventsPage({super.key, required this.userPosition});

  @override
  State<EventsPage> createState() => _EventsPageState();
}

class _EventsPageState extends State<EventsPage> {
  // Daftar event kampus
  final List<EventModel> events = [
    EventModel(
      title: 'Seminar Artificial Intelligence',
      description:
          'Workshop tentang Machine Learning dan Deep Learning untuk mahasiswa',
      latitude: -7.4246,
      longitude: 109.2332,
      date: DateTime(2025, 11, 20, 9, 0),
      venue: 'Auditorium Utama',
      category: 'Seminar',
    ),
    EventModel(
      title: 'Job Fair 2025',
      description:
          'Bursa kerja untuk fresh graduate dan mahasiswa tingkat akhir',
      latitude: -7.4261,
      longitude: 109.2315,
      date: DateTime(2025, 11, 22, 8, 0),
      venue: 'Lapangan Parkir A',
      category: 'Career',
    ),
    EventModel(
      title: 'Expo UKM & Kesenian',
      description: 'Pameran unit kegiatan mahasiswa dan penampilan seni',
      latitude: -7.4229,
      longitude: 109.2350,
      date: DateTime(2025, 11, 25, 10, 0),
      venue: 'Hall Serba Guna',
      category: 'Exhibition',
    ),
    EventModel(
      title: 'Kompetisi Programming',
      description: 'Lomba competitive programming tingkat universitas',
      latitude: -7.4238,
      longitude: 109.2340,
      date: DateTime(2025, 11, 28, 13, 0),
      venue: 'Lab Komputer 1',
      category: 'Competition',
    ),
    EventModel(
      title: 'Workshop Mobile Development',
      description: 'Belajar membuat aplikasi Android & iOS dengan Flutter',
      latitude: -7.4255,
      longitude: 109.2325,
      date: DateTime(2025, 12, 1, 9, 0),
      venue: 'Ruang Multimedia',
      category: 'Workshop',
    ),
  ];

  String _sortBy = 'distance';

  @override
  void initState() {
    super.initState();
    _calculateDistances();
    _sortEvents();
  }

  void _calculateDistances() {
    for (var event in events) {
      event.distance = Geolocator.distanceBetween(
        widget.userPosition.latitude,
        widget.userPosition.longitude,
        event.latitude,
        event.longitude,
      );
    }
  }

  void _sortEvents() {
    setState(() {
      if (_sortBy == 'distance') {
        events.sort((a, b) => (a.distance ?? 0).compareTo(b.distance ?? 0));
      } else if (_sortBy == 'date') {
        events.sort((a, b) => a.date.compareTo(b.date));
      }
    });
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Seminar':
        return Colors.blue;
      case 'Career':
        return Colors.green;
      case 'Exhibition':
        return Colors.orange;
      case 'Competition':
        return Colors.red;
      case 'Workshop':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Seminar':
        return Icons.school;
      case 'Career':
        return Icons.work;
      case 'Exhibition':
        return Icons.palette;
      case 'Competition':
        return Icons.emoji_events;
      case 'Workshop':
        return Icons.build;
      default:
        return Icons.event;
    }
  }

  String _formatDistance(double meters) {
    if (meters < 1000) {
      return '${meters.toStringAsFixed(0)} m';
    } else {
      return '${(meters / 1000).toStringAsFixed(2)} km';
    }
  }

  String _formatDate(DateTime date) {
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Ags',
      'Sep',
      'Oct',
      'Nov',
      'Des',
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}, ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Event Kampus'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            onSelected: (value) {
              setState(() {
                _sortBy = value;
                _sortEvents();
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'distance',
                child: Row(
                  children: [
                    Icon(Icons.near_me),
                    SizedBox(width: 8),
                    Text('Urutkan: Jarak'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'date',
                child: Row(
                  children: [
                    Icon(Icons.calendar_today),
                    SizedBox(width: 8),
                    Text('Urutkan: Tanggal'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // User Location Card
          Container(
            width: double.infinity,
            color: Theme.of(context).primaryColor.withOpacity(0.1),
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(
                  Icons.person_pin_circle,
                  color: Theme.of(context).primaryColor,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Lokasi Anda',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Lat: ${widget.userPosition.latitude.toStringAsFixed(4)}, '
                        'Lng: ${widget.userPosition.longitude.toStringAsFixed(4)}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Events List
          Expanded(
            child: events.isEmpty
                ? const Center(child: Text('Tidak ada event'))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: events.length,
                    itemBuilder: (context, index) {
                      final event = events[index];
                      final color = _getCategoryColor(event.category);
                      final icon = _getCategoryIcon(event.category);

                      return Card(
                        margin: const EdgeInsets.only(bottom: 16),
                        elevation: 2,
                        child: InkWell(
                          onTap: () => _showEventDetail(event),
                          borderRadius: BorderRadius.circular(12),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: color.withOpacity(0.2),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Icon(icon, color: color, size: 24),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            event.title,
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleMedium
                                                ?.copyWith(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                          ),
                                          const SizedBox(height: 4),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 2,
                                            ),
                                            decoration: BoxDecoration(
                                              color: color.withOpacity(0.2),
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                            ),
                                            child: Text(
                                              event.category,
                                              style: TextStyle(
                                                color: color,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  event.description,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 12),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.location_on,
                                      size: 16,
                                      color: Colors.grey[600],
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        event.venue,
                                        style: TextStyle(
                                          color: Colors.grey[600],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.calendar_today,
                                      size: 16,
                                      color: Colors.grey[600],
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      _formatDate(event.date),
                                      style: TextStyle(color: Colors.grey[600]),
                                    ),
                                  ],
                                ),
                                const Divider(height: 24),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.near_me,
                                          size: 18,
                                          color: Theme.of(context).primaryColor,
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          _formatDistance(event.distance ?? 0),
                                          style: TextStyle(
                                            color: Theme.of(
                                              context,
                                            ).primaryColor,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        Text(
                                          ' dari lokasi Anda',
                                          style: TextStyle(
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                      ],
                                    ),
                                    TextButton(
                                      onPressed: () => _showEventDetail(event),
                                      child: const Text('Detail'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _showEventDetail(EventModel event) {
    final color = _getCategoryColor(event.category);
    final icon = _getCategoryIcon(event.category);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(icon, color: color, size: 32),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          event.title,
                          style: Theme.of(context).textTheme.headlineSmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            event.category,
                            style: TextStyle(
                              color: color,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              _buildDetailRow(
                Icons.description,
                'Deskripsi',
                event.description,
              ),
              const SizedBox(height: 16),
              _buildDetailRow(Icons.location_on, 'Tempat', event.venue),
              const SizedBox(height: 16),
              _buildDetailRow(
                Icons.calendar_today,
                'Tanggal & Waktu',
                _formatDate(event.date),
              ),
              const SizedBox(height: 16),
              _buildDetailRow(
                Icons.near_me,
                'Jarak dari Anda',
                _formatDistance(event.distance ?? 0),
              ),
              const SizedBox(height: 16),
              _buildDetailRow(
                Icons.map,
                'Koordinat',
                'Lat: ${event.latitude.toStringAsFixed(6)}\n'
                    'Lng: ${event.longitude.toStringAsFixed(6)}',
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    // Bisa tambahkan navigasi ke maps
                  },
                  icon: const Icon(Icons.directions),
                  label: const Text('Lihat di Peta'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 24, color: Colors.grey[600]),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
