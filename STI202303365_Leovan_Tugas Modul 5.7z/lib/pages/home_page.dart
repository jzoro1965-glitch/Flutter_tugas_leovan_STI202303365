import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart' as gc;
import 'google_maps_page.dart';
import 'osm_map_page.dart';
import 'events_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Position? _pos;
  String? _address;
  StreamSubscription<Position>? _sub;
  bool _tracking = false;
  String _status = 'Tekan tombol untuk memulai';
  bool _isLoading = false;

  // Accuracy settings
  LocationAccuracy _accuracy = LocationAccuracy.high;
  int _distanceFilter = 10;

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  // Cek service dan permission
  Future<bool> _ensureServiceAndPermission() async {
    setState(() => _isLoading = true);

    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        _status = 'Layanan lokasi MATI. Silakan aktifkan di pengaturan.';
        _isLoading = false;
      });
      await Geolocator.openLocationSettings();
      return false;
    }

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }

    if (perm == LocationPermission.deniedForever ||
        perm == LocationPermission.denied) {
      setState(() {
        _status = 'Izin lokasi ditolak. Silakan aktifkan melalui Settings.';
        _isLoading = false;
      });
      return false;
    }

    setState(() => _isLoading = false);
    return true;
  }

  // Get current location (one-time)
  Future<void> _getCurrent() async {
    if (!await _ensureServiceAndPermission()) return;

    setState(() {
      _isLoading = true;
      _status = 'Mengambil lokasi...';
    });

    try {
      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: _accuracy,
        timeLimit: const Duration(seconds: 15),
      );

      setState(() {
        _pos = p;
        _status = 'Lokasi berhasil diambil (one-time)';
        _isLoading = false;
      });

      await _reverseGeocode(p);
    } catch (e) {
      setState(() {
        _status = 'Gagal mengambil lokasi: $e';
        _isLoading = false;
      });
    }
  }

  // Reverse geocoding untuk mendapat alamat
  Future<void> _reverseGeocode(Position p) async {
    try {
      final placemarks = await gc.placemarkFromCoordinates(
        p.latitude,
        p.longitude,
      );

      if (placemarks.isNotEmpty) {
        final m = placemarks.first;
        setState(() {
          _address =
              '${m.street ?? ''}, ${m.locality ?? ''}, ${m.administrativeArea ?? ''}';
        });
      }
    } catch (e) {
      setState(() => _address = 'Alamat tidak tersedia');
    }
  }

  // Toggle tracking (continuous)
  Future<void> _toggleTracking() async {
    if (_tracking) {
      // Stop tracking
      await _sub?.cancel();
      setState(() {
        _tracking = false;
        _status = 'Tracking dihentikan';
      });
      return;
    }

    // Start tracking
    if (!await _ensureServiceAndPermission()) return;

    final settings = LocationSettings(
      accuracy: _accuracy,
      distanceFilter: _distanceFilter,
    );

    setState(() {
      _status = 'Memulai tracking...';
    });

    _sub = Geolocator.getPositionStream(locationSettings: settings).listen(
      (p) {
        setState(() {
          _pos = p;
          _tracking = true;
          _status = 'Tracking aktif (update setiap ${_distanceFilter}m)';
        });
        _reverseGeocode(p);
      },
      onError: (e) {
        setState(() {
          _status = 'Error stream: $e';
          _tracking = false;
        });
      },
    );
  }

  // Dialog untuk settings accuracy
  void _showAccuracyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pengaturan Akurasi'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<LocationAccuracy>(
              title: const Text('Low (hemat baterai)'),
              value: LocationAccuracy.low,
              groupValue: _accuracy,
              onChanged: (val) {
                setState(() => _accuracy = val!);
                Navigator.pop(context);
              },
            ),
            RadioListTile<LocationAccuracy>(
              title: const Text('Medium'),
              value: LocationAccuracy.medium,
              groupValue: _accuracy,
              onChanged: (val) {
                setState(() => _accuracy = val!);
                Navigator.pop(context);
              },
            ),
            RadioListTile<LocationAccuracy>(
              title: const Text('High (akurat)'),
              value: LocationAccuracy.high,
              groupValue: _accuracy,
              onChanged: (val) {
                setState(() => _accuracy = val!);
                Navigator.pop(context);
              },
            ),
            const Divider(),
            ListTile(
              title: const Text('Distance Filter'),
              subtitle: Slider(
                value: _distanceFilter.toDouble(),
                min: 0,
                max: 100,
                divisions: 10,
                label: '${_distanceFilter}m',
                onChanged: (val) {
                  setState(() => _distanceFilter = val.toInt());
                },
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Event Kampus Locator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _showAccuracyDialog,
            tooltip: 'Pengaturan Akurasi',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          _tracking ? Icons.sensors : Icons.sensors_off,
                          color: _tracking ? Colors.green : Colors.grey,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Status: $_status',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ),
                      ],
                    ),
                    if (_isLoading)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: LinearProgressIndicator(),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Location Info Card
            if (_pos != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Informasi Lokasi',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const Divider(),
                      _buildInfoRow(
                        Icons.location_on,
                        'Latitude',
                        _pos!.latitude.toStringAsFixed(6),
                      ),
                      _buildInfoRow(
                        Icons.location_on,
                        'Longitude',
                        _pos!.longitude.toStringAsFixed(6),
                      ),
                      _buildInfoRow(
                        Icons.my_location,
                        'Akurasi',
                        '${_pos!.accuracy.toStringAsFixed(1)} m',
                      ),
                      _buildInfoRow(
                        Icons.speed,
                        'Kecepatan',
                        '${(_pos!.speed * 3.6).toStringAsFixed(1)} km/h',
                      ),
                      _buildInfoRow(
                        Icons.explore,
                        'Heading',
                        '${_pos!.heading.toStringAsFixed(0)}°',
                      ),
                      _buildInfoRow(
                        Icons.access_time,
                        'Waktu',
                        _pos!.timestamp.toString().substring(0, 19),
                      ),
                      if (_address != null)
                        _buildInfoRow(Icons.home, 'Alamat', _address!),
                    ],
                  ),
                ),
              )
            else
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.location_off,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Belum ada data lokasi',
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 24),

            // Action Buttons
            Text('Aksi Lokasi', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _getCurrent,
                  icon: const Icon(Icons.my_location),
                  label: const Text('Get Current'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                  ),
                ),
                FilledButton.icon(
                  onPressed: _isLoading ? null : _toggleTracking,
                  icon: Icon(_tracking ? Icons.stop : Icons.play_arrow),
                  label: Text(_tracking ? 'Stop Tracking' : 'Start Tracking'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Navigation Buttons
            Text(
              'Peta & Event',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => GoogleMapsPage(initialPosition: _pos),
                      ),
                    );
                  },
                  icon: const Icon(Icons.map),
                  label: const Text('Google Maps'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => OsmMapPage(initialPosition: _pos),
                      ),
                    );
                  },
                  icon: const Icon(Icons.map_outlined),
                  label: const Text('OpenStreetMap'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: () {
                    if (_pos == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Ambil lokasi terlebih dahulu'),
                        ),
                      );
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => EventsPage(userPosition: _pos!),
                      ),
                    );
                  },
                  icon: const Icon(Icons.event),
                  label: const Text('Daftar Event'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Info Card
            Card(
              color: Colors.blue[50],
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info_outline, color: Colors.blue[700]),
                        const SizedBox(width: 8),
                        Text(
                          'Informasi',
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(color: Colors.blue[700]),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '• Gunakan "Get Current" untuk lokasi satu kali\n'
                      '• Gunakan "Start Tracking" untuk pemantauan berkelanjutan\n'
                      '• Atur akurasi di tombol Settings (⚙️)\n'
                      '• Distance Filter mengatur frekuensi update',
                      style: TextStyle(color: Colors.blue[900]),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey[600]),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[700]),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }
}
