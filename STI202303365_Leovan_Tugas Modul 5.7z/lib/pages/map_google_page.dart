import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class GoogleMapPage extends StatefulWidget {
  final Position? position;

  const GoogleMapPage({super.key, this.position});

  @override
  State<GoogleMapPage> createState() => _GoogleMapPageState();
}

class _GoogleMapPageState extends State<GoogleMapPage> {
  GoogleMapController? _controller;

  @override
  Widget build(BuildContext context) {
    final pos = widget.position;

    final LatLng center = pos != null
        ? LatLng(pos.latitude, pos.longitude)
        : const LatLng(-7.4246, 109.2332);

    final markers = {
      Marker(
        markerId: const MarkerId("me"),
        position: center,
        infoWindow: const InfoWindow(title: "Posisi Saya"),
      ),
    };

    return Scaffold(
      appBar: AppBar(title: const Text("Google Map")),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(target: center, zoom: 16),
        myLocationEnabled: true,
        markers: markers,
        onMapCreated: (c) => _controller = c,
      ),
    );
  }
}
