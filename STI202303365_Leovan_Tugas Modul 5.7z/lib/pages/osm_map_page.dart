import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';

class OsmMapPage extends StatefulWidget {
  final Position? initialPosition;

  const OsmMapPage({super.key, this.initialPosition});

  @override
  State<OsmMapPage> createState() => _OsmMapPageState();
}

class _OsmMapPageState extends State<OsmMapPage> {
  Position? _pos;
  final MapController _mapController = MapController();

  // Event locations
  final List<Map<String, dynamic>> _events = [
    {
      'title': 'Seminar AI',
      'lat': -7.4246,
      'lng': 109.2332,
      'description': 'Workshop ML & Deep Learning',
      'icon': Icons.school,
      'color': Colors.blue,
    },
    {
      'title': 'Job Fair',
      'lat': -7.4261,
      'lng': 109.2315,
      'description': 'Bursa kerja 2025',
      'icon': Icons.work,
      'color': Colors.green,
    },
    {
      'title': 'Expo UKM',
      'lat': -7.4229,
      'lng': 109.2350,
      'description': 'Pameran UKM & Kesenian',
      'icon': Icons.palette,
      'color': Colors.orange,
    },
    {
      'title': 'Kompetisi Programming',
      'lat': -7.4238,
      'lng': 109.2340,
      'description': 'Competitive Programming',
      'icon': Icons.emoji_events,
      'color': Colors.red,
    },
    {
      'title': 'Workshop Flutter',
      'lat': -7.4255,
      'lng': 109.2325,
      'description': 'Mobile Development',
      'icon': Icons.build,
      'color': Colors.purple,
    },
  ];

  @override
  void initState() {
    super.initState();
    if (widget.initialPosition != null) {
      _pos = widget.initialPosition;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _moveCamera();
      });
    } else {
      _initLocation();
    }
  }

  Future<void> _initLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showSnackBar('Layanan lokasi tidak aktif');
      return;
    }

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }

    if (perm == LocationPermission.deniedForever ||
        perm == LocationPermission.denied) {
      _showSnackBar('Izin lokasi ditolak');
      return;
    }

    try {
      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
      setState(() {
        _pos = p;
      });
      _moveCamera();
    } catch (e) {
      _showSnackBar('Gagal mendapatkan lokasi: $e');
    }
  }

  void _moveCamera() {
    if (_pos == null) return;
    _mapController.move(LatLng(_pos!.latitude, _pos!.longitude), 15);
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  double _calculateDistance(Map<String, dynamic> event) {
    if (_pos == null) return 0;
    return Geolocator.distanceBetween(
      _pos!.latitude,
      _pos!.longitude,
      event['lat'],
      event['lng'],
    );
  }

  void _showEventInfo(Map<String, dynamic> event) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(event['icon'], color: event['color']),
            const SizedBox(width: 8),
            Expanded(child: Text(event['title'])),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(event['description']),
            const SizedBox(height: 8),
            Text(
              'Koordinat:\nLat: ${event['lat']}\nLng: ${event['lng']}',
              style: TextStyle(color: Colors.grey[600], fontSize: 12),
            ),
            if (_pos != null) ...[
              const SizedBox(height: 8),
              Text(
                'Jarak: ${_calculateDistance(event).toStringAsFixed(0)} m',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              _mapController.move(LatLng(event['lat'], event['lng']), 17);
            },
            child: const Text('Lihat'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final center = _pos != null
        ? LatLng(_pos!.latitude, _pos!.longitude)
        : const LatLng(-7.4246, 109.2332);

    return Scaffold(
      appBar: AppBar(
        title: const Text('OpenStreetMap'),
        actions: [
          if (_pos != null)
            IconButton(
              icon: const Icon(Icons.my_location),
              onPressed: _moveCamera,
              tooltip: 'Kembali ke lokasi saya',
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () async {
              await _initLocation();
              _showSnackBar('Lokasi diperbarui');
            },
            tooltip: 'Perbarui lokasi',
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: center,
              initialZoom: 14,
              minZoom: 5,
              maxZoom: 18,
            ),
            children: [
              // Tile Layer (OSM)
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.event_kampus_locator',
                tileBuilder: (context, tileWidget, tile) {
                  return tileWidget;
                },
              ),

              // User location marker
              if (_pos != null)
                MarkerLayer(
                  markers: [
                    Marker(
                      point: LatLng(_pos!.latitude, _pos!.longitude),
                      width: 60,
                      height: 60,
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 6,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.person_pin_circle,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

              // Event markers
              MarkerLayer(
                markers: _events.map((event) {
                  return Marker(
                    point: LatLng(event['lat'], event['lng']),
                    width: 50,
                    height: 50,
                    child: GestureDetector(
                      onTap: () => _showEventInfo(event),
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: event['color'],
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 4,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            child: Icon(
                              event['icon'],
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),

              // Attribution
              RichAttributionWidget(
                attributions: [
                  TextSourceAttribution(
                    'OpenStreetMap contributors',
                    onTap: () {},
                  ),
                ],
              ),
            ],
          ),

          // Info banner at the top
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: Colors.blue),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        '🔵 Biru = Lokasi Anda | 🎯 Warna = Event',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Event list at bottom
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Card(
              child: ExpansionTile(
                leading: const Icon(Icons.event),
                title: const Text('Daftar Event'),
                children: _events.map((event) {
                  final distance = _pos != null ? _calculateDistance(event) : 0;
                  return ListTile(
                    leading: Icon(event['icon'], color: event['color']),
                    title: Text(event['title']),
                    subtitle: Text(event['description']),
                    trailing: _pos != null
                        ? Text(
                            '${distance.toStringAsFixed(0)} m',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          )
                        : null,
                    onTap: () => _showEventInfo(event),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'zoom_in',
            onPressed: () {
              _mapController.move(
                _mapController.camera.center,
                _mapController.camera.zoom + 1,
              );
            },
            child: const Icon(Icons.add),
          ),
          const SizedBox(height: 8),
          FloatingActionButton.small(
            heroTag: 'zoom_out',
            onPressed: () {
              _mapController.move(
                _mapController.camera.center,
                _mapController.camera.zoom - 1,
              );
            },
            child: const Icon(Icons.remove),
          ),
        ],
      ),
    );
  }
}
