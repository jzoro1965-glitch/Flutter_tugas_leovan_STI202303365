import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class GoogleMapsPage extends StatefulWidget {
  final Position? initialPosition;

  const GoogleMapsPage({super.key, this.initialPosition});

  @override
  State<GoogleMapsPage> createState() => _GoogleMapsPageState();
}

class _GoogleMapsPageState extends State<GoogleMapsPage> {
  GoogleMapController? _controller;
  Position? _pos;
  final Set<Marker> _markers = {};

  // Event locations
  final List<Map<String, dynamic>> _events = [
    {
      'title': 'Seminar AI',
      'lat': -7.4246,
      'lng': 109.2332,
      'description': 'Workshop ML & Deep Learning',
    },
    {
      'title': 'Job Fair',
      'lat': -7.4261,
      'lng': 109.2315,
      'description': 'Bursa kerja 2025',
    },
    {
      'title': 'Expo UKM',
      'lat': -7.4229,
      'lng': 109.2350,
      'description': 'Pameran UKM & Kesenian',
    },
    {
      'title': 'Kompetisi Programming',
      'lat': -7.4238,
      'lng': 109.2340,
      'description': 'Competitive Programming',
    },
    {
      'title': 'Workshop Flutter',
      'lat': -7.4255,
      'lng': 109.2325,
      'description': 'Mobile Development',
    },
  ];

  @override
  void initState() {
    super.initState();
    if (widget.initialPosition != null) {
      _pos = widget.initialPosition;
      _updateMarkers();
    } else {
      _initLocation();
    }
  }

  Future<void> _initLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showSnackBar('Layanan lokasi tidak aktif');
      return;
    }

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }

    if (perm == LocationPermission.deniedForever ||
        perm == LocationPermission.denied) {
      _showSnackBar('Izin lokasi ditolak');
      return;
    }

    try {
      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
      setState(() {
        _pos = p;
      });
      _updateMarkers();
      _moveCamera();
    } catch (e) {
      _showSnackBar('Gagal mendapatkan lokasi: $e');
    }
  }

  void _updateMarkers() {
    _markers.clear();

    // Add user location marker
    if (_pos != null) {
      _markers.add(
        Marker(
          markerId: const MarkerId('me'),
          position: LatLng(_pos!.latitude, _pos!.longitude),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: const InfoWindow(
            title: '📍 Posisi Saya',
            snippet: 'Lokasi saat ini',
          ),
        ),
      );
    }

    // Add event markers
    for (var i = 0; i < _events.length; i++) {
      final event = _events[i];
      _markers.add(
        Marker(
          markerId: MarkerId('event_$i'),
          position: LatLng(event['lat'], event['lng']),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: InfoWindow(
            title: event['title'],
            snippet: event['description'],
          ),
          onTap: () => _showEventInfo(event),
        ),
      );
    }

    setState(() {});
  }

  void _moveCamera() {
    if (_controller == null || _pos == null) return;
    _controller!.animateCamera(
      CameraUpdate.newLatLngZoom(LatLng(_pos!.latitude, _pos!.longitude), 15),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _showEventInfo(Map<String, dynamic> event) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(event['title']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(event['description']),
            const SizedBox(height: 8),
            Text(
              'Koordinat:\nLat: ${event['lat']}\nLng: ${event['lng']}',
              style: TextStyle(color: Colors.grey[600], fontSize: 12),
            ),
            if (_pos != null) ...[
              const SizedBox(height: 8),
              Text(
                'Jarak: ${_calculateDistance(event).toStringAsFixed(0)} m',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  double _calculateDistance(Map<String, dynamic> event) {
    if (_pos == null) return 0;
    return Geolocator.distanceBetween(
      _pos!.latitude,
      _pos!.longitude,
      event['lat'],
      event['lng'],
    );
  }

  @override
  Widget build(BuildContext context) {
    final center = _pos != null
        ? LatLng(_pos!.latitude, _pos!.longitude)
        : const LatLng(-7.4246, 109.2332);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Google Maps'),
        actions: [
          if (_pos != null)
            IconButton(
              icon: const Icon(Icons.my_location),
              onPressed: _moveCamera,
              tooltip: 'Kembali ke lokasi saya',
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () async {
              await _initLocation();
              _showSnackBar('Lokasi diperbarui');
            },
            tooltip: 'Perbarui lokasi',
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: center, zoom: 14),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            markers: _markers,
            onMapCreated: (c) {
              _controller = c;
              if (_pos != null) {
                _moveCamera();
              }
            },
            mapType: MapType.normal,
            compassEnabled: true,
            zoomControlsEnabled: false,
          ),

          // Info banner at the top
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: Colors.blue),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        '📍 Biru = Lokasi Anda | 📍 Merah = Event Kampus',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Event list button
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Card(
              child: ExpansionTile(
                leading: const Icon(Icons.event),
                title: const Text('Daftar Event'),
                children: _events.map((event) {
                  final distance = _pos != null ? _calculateDistance(event) : 0;
                  return ListTile(
                    leading: const Icon(Icons.location_on, color: Colors.red),
                    title: Text(event['title']),
                    subtitle: Text(event['description']),
                    trailing: _pos != null
                        ? Text(
                            '${distance.toStringAsFixed(0)} m',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          )
                        : null,
                    onTap: () {
                      _controller?.animateCamera(
                        CameraUpdate.newLatLngZoom(
                          LatLng(event['lat'], event['lng']),
                          17,
                        ),
                      );
                      _showEventInfo(event);
                    },
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }
}
